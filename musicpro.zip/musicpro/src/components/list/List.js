import React , {Component} from 'react';
import './List.css';
import axios from 'axios'
import {connect} from 'react-redux';
import Loading from '../loading/Loading';
import {getSessionStory,setSessionStory} from '../../tools/tools';
class ListUI extends Component{
	constructor(){
		super();
		this.state = {
			musicList : [],
			isLoading: true
		}
		this.isMove = false;
		this.handleMove = this.handleMove.bind(this);
		this.handleEnd = this.handleEnd.bind(this);
	}
	render(){
		return (
			<div id="musicList" ref="musicList">
			<ul>
				{
					this.state.isLoading ? <Loading></Loading> : 
					this.state.musicList.map((item,index)=>{
						return(
							<li key = {item.id} onTouchMove={this.handleMove} onTouchEnd={()=>{
								this.handleEnd(item.id,item.title)
							}} className={this.props.musicNameId === '' + item.id ? 'active' : ''}>
								<div className="listOrder">{index + 1}</div>
								<div className="listName">
									<h3>{item.title}</h3>
									<p>{item.author}</p>
								</div>
							</li>
						);
					})
				}
			</ul>
		</div>
		);
	}
	componentDidMount(){
		var musicList = getSessionStory('musicList');
		//判断缓存中是否存在数据
		if(musicList){
			this.setState({
				musicList: JSON.parse(musicList),
				isLoading: false,
			},()=>{
				this.listScrollTop();
			});
		}else{
			axios.post('/api/index/index',{
				"TransCode" : "020111",
				"OpenId" : "Test",
				"Body":{"SongListId" : "141998290"}
			}).then((res) => {
				if(res.data.ErrCode === "OK"){
					var musicList = res.data.Body.songs;
					this.setState({
						musicList,
						isLoading: false	
					},()=>{
						this.listScrollTop();
						//设置数据缓存
						setSessionStory('musicList',JSON.stringify(this.state.musicList));
					});
				}
			});
		}
	}
	handleMove(){
		this.isMove = true;
	}
	handleEnd(id,musicName){
		if(this.isMove){
			this.isMove = false;
		}else{
			this.props.history.push('/lyric/'+id);
			this.props.musicNameIdFn(id);
			this.props.isMusicPlayFn();
			this.props.musicNameFn(musicName);
		}
	}
	listScrollTop(){
		var musicList = this.refs.musicList;
		var musicListLi = musicList.getElementsByTagName('li');
		for(var i = 0; i < musicListLi.length; i++){
			if(musicListLi[i].className){
				musicList.scrollTop = musicListLi[i].offsetTop;
			}
		}
	}
}
function mapStateToProps(state){
    return {
		musicNameId:state.musicNameId
    }
}
function mapDispatchToProps(dispatch){
    return {
        musicNameIdFn(id){
            dispatch({
                type:'MUSICNAMEID_CHANGE',
                payload:id
            })
		},
		isMusicPlayFn(){
			dispatch({
                type:'ISMUSICPLAY_CHANGE',
                payload:true
            })
		},
		musicNameFn(musicName){
			dispatch({
                type:'MUSICNAME_CHANGE',
                payload:musicName
            })
		}
    }
}
var List = connect(mapStateToProps,mapDispatchToProps)(ListUI)
export default List;