import React , {Component} from 'react';
import './Header.css';
import {connect} from 'react-redux';
import {NavLink} from 'react-router-dom';
class HeaderUI extends Component{
    render(){
        return (
            <div id="musicHeader">
                {this.props.headerArrow && <NavLink to="/list"><span>&lt;</span></NavLink>}
                {this.props.musicName}
            </div>
        );
    }
}
function mapStateToProps(state){
    return {
        headerArrow:state.headerArrow,
        musicName: state.musicName
    }
}
function mapDispatchToProps(){
    return {}
}
var Header = connect(mapStateToProps,mapDispatchToProps)(HeaderUI);
export default Header;