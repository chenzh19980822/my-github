import React , {Component,Fragment} from 'react';
import './Lyric.css';
import axios from 'axios';
import {connect} from 'react-redux';
class LyricUI extends Component{
    constructor(){
        super();
        this.state = {
            lyricList : [],
            active: -1

        }
        // this.formatTimeToSec = this.formatTimeToSec.bind(this)
    }
    render(){
        return (
            <Fragment>
            <div id="musicLyric">
                <ul ref = "musicLyricUl">
                    {
                        this.state.lyricList.map((item,index) => {
                            return <li key = {index + 1} className={this.state.active === index ? 'active':'' }>{item.lyric}</li>
                        })
                    }
                </ul>
            </div>
            </Fragment>
        )
    }
    componentDidMount(){
        var id = this.props.match.params.id;
        axios.get('/music/Music/Music?id='+id+'&type=lrc').then((res)=>{
           this.setState({
                lyricList:this.myLyricData(res.data)
           })
        })
        this.props.headerArrowFn();
        this.props.musicNameIdFn(id);
        if(this.props.isMusicPlay){
            this.lyricPlay();
        }else{
            this.lyricPause();
        }
    }
    componentWillReceiveProps(nextProps){
        //传递进入当前组件props发生变化的时候
        if(nextProps.isMusicPlay){
            this.lyricPlay();
        }else{
            this.lyricPause();
        }
    }
    componentWillUnmount(){
        this.lyricPause();
    }
    myLyricData(lyrics){
        var result = [];
        var reg =  /\[([^\]]+)\]([^[]+)/g;
        lyrics.replace(reg,($0,$1,$2)=>{
            result.push({time:this.formatTimeToSec($1),lyric:$2});
        })
        return result
    }
    formatTimeToSec(time){
        var arr = time.split(':');
        return (parseFloat(arr[0] * 60) + parseFloat(arr[1])).toFixed(2)
    }
    lyricPlay(){
        this.playing();
        this.timer = setInterval(this.playing.bind(this),500);
    }
    lyricPause(){
        clearInterval(this.timer);
    }
    playing(){
        var lyricList = this.state.lyricList;
        var audio = document.getElementById('audio');
        var musicLyricUl = this.refs.musicLyricUl;
        var musicLyricLi = musicLyricUl.getElementsByTagName('li')[0];
        for(var i = 0; i < lyricList.length; i++){
            if(i === lyricList.length - 1){continue}
            else if(lyricList[i].time < audio.currentTime && lyricList[i+1].time > audio.currentTime){
                this.setState({
                    active: i,
                });
                if(i > 5){
                    musicLyricUl.style.top = -(i - 5)*(musicLyricLi.offsetHeight + 8) + 'px';
                }
            }
        }
    }
}
function mapStateToProps(state){
    return {
        isMusicPlay:state.isMusicPlay
    }
}
function mapDispatchToProps(dispatch){
    return {
        headerArrowFn(){
            dispatch({
                type:'HEDERARROW_CHANGE',
                payload:true
            })
        },
        musicNameIdFn(id){
            dispatch({
                type:'MUSICNAMEID_CHANGE',
                payload: id
            })
        },
       
    }
}
var Lyric = connect(mapStateToProps,mapDispatchToProps)(LyricUI)
export default Lyric;