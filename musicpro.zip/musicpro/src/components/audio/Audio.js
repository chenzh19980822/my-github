import React , {Component} from 'react';
import './Audio.css'
import {connect} from 'react-redux'
class AudioUI extends Component {
	constructor(){
		super();
		this.handelTap = this.handelTap.bind(this);
	}
    render(){
        return(
            <div id="musicAudio">
			<div ref="audioPlay" className="audioPlay" onTouchStart={this.handelTap}></div>
			<div className="audioProgress" ref = "audioProgress">
				<div className="audioBar" ref="audioBar"></div>
				<div className="audioNow" ref="audioNow"></div>
			</div>
			<audio id="audio" ref="audio" src={"/music/Music/Music?id="+this.props.musicNameId+"&type=url"}></audio>
		</div>
        )
	}
	componentDidUpdate(){
		if(this.props.isMusicPlay){
			this.audioPlay();
		}else{
			this.audioPause();
		}
	}
	componentDidMount(){
		this.handelMove();
	}
	audioPlay(){
		this.refs.audioPlay.style.backgroundImage = 'url(/images/list_audioPause.png)'
		this.refs.audio.play();
		this.playing();
		this.timer = setInterval(this.playing.bind(this),1000)
	}
	audioPause(){
		this.refs.audioPlay.style.backgroundImage = 'url(/images/list_audioPlay.png)'
		this.refs.audio.pause();
		clearInterval(this.timer)
	}
	handelTap(){
		if(this.refs.audio.paused){
			this.props.isMusicPlayFn(true);
		}else{
			this.props.isMusicPlayFn(false);
		}
	}
	playing(){
		var audioProgress = this.refs.audioProgress;
		var audioBar = this.refs.audioBar;
		var audioNow = this.refs.audioNow;
		var audio = this.refs.audio;
		var scale = audio.currentTime / audio.duration;
		audioBar.style.left = scale * audioProgress.offsetWidth + 'px';
		audioNow.style.width = scale * 100 + '%';
	}
	handelMove(){
		var audioProgress = this.refs.audioProgress;
		var audioBar = this.refs.audioBar;
		var audioNow = this.refs.audioNow;
		var audio = this.refs.audio;
		var disX = 0;
		audioBar.ontouchstart = function(ev){
			var This = this
			var touch = ev.changedTouches[0];
			disX = touch.pageX - this.offsetLeft;
			document.ontouchmove = function(ev){
				var touch = ev.changedTouches[0];
				var L = touch.pageX - disX;
				if(L < 0){
					L = 0;
				}else if(L > audioProgress.offsetWidth){
					L = audioProgress.offsetWidth;
				}
				This.style.left = L + 'px';
				var scale = L / audioProgress.offsetWidth;
				audio.currentTime = scale * audio.duration;
				audioNow.style.width = scale * 100 + '%';
			}
		}
	}
}
function mapStateToProps(state){
    return {
		isMusicPlay:state.isMusicPlay,
		musicNameId:state.musicNameId
    }
}
function mapDispatchToProps(dispatch){
    return {
        isMusicPlayFn(bool){
            dispatch({
                type:'ISMUSICPLAY_CHANGE',
                payload:bool
            })
        }
    }
}
var Audio = connect(mapStateToProps,mapDispatchToProps)(AudioUI)
export default Audio;