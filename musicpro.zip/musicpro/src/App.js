import React ,{Component} from 'react'
import './App.css';
import {BrowserRouter as Router ,Route, Redirect, Switch} from 'react-router-dom';
import Header from './components/header/Header';
import List from './components/list/List';
import Audio from './components/audio/Audio';
import Lyric from './components/lyric/Lyric';
class App extends Component{
  render(){
    return (
      <Router>
        <div id = "main">
        <Header />
        <Switch >
          <Route path = '/list' component ={List} />
          <Route path = '/lyric/:id'  component ={Lyric} />
          <Redirect from = "/*" to = "/list" />
        </Switch>
        <Audio />
      </div>
      </Router>
    );
  }
}

export default App;
