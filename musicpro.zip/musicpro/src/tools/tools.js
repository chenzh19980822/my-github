function getSessionStory(key){
    return window.sessionStorage.getItem(key);
}
function setSessionStory(key,value){
    return window.sessionStorage.setItem(key,value);
}
export {
    getSessionStory,
    setSessionStory,
}